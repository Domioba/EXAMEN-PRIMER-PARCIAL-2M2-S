﻿using System;
using System.Collections.Generic;
using System.Threading;

public class VariableFinanciera
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public decimal Valor { get; set; }
}

public class GestionVariablesFinancieras
{
    private List<VariableFinanciera> variables;

    public GestionVariablesFinancieras()
    {
        variables = new List<VariableFinanciera>();
    }

    public void AgregarVariable(VariableFinanciera variable)
    {
        variables.Add(variable);
    }

    public void MostrarVariables()
    {
        Console.WriteLine("Listado de Variables Financieras:");
        foreach (var variable in variables)
        {
            Console.WriteLine($"ID: {variable.Id}, Nombre: {variable.Nombre}, Valor: {variable.Valor}");
        }
    }

    public void ActualizarVariable(int id, VariableFinanciera variableActualizada)
    {
        var variableExistente = variables.Find(v => v.Id == id);
        if (variableExistente != null)
        {
            variableExistente.Nombre = variableActualizada.Nombre;
            variableExistente.Valor = variableActualizada.Valor;
            Console.WriteLine("Variable financiera actualizada correctamente.");
        }
        else
        {
            Console.WriteLine("Variable financiera no encontrada.");
        }
    }

    public void EliminarVariable(int id)
    {
        var variableExistente = variables.Find(v => v.Id == id);
        if (variableExistente != null)
        {
            variables.Remove(variableExistente);
            Console.WriteLine("Variable financiera eliminada correctamente.");
        }
        else
        {
            Console.WriteLine("Variable financiera no encontrada.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Thread t = new Thread(metedohilo1);
        t.Start();
        t.Join();
        Thread t2 = new Thread(metedohilo2);
        t2.Start();
        t2.Join();
        Thread t3 = new Thread(metedohilo3);
        t3.Start();
        t3.Join();
    }

    static void metedohilo1()
    {
        GestionVariablesFinancieras gestionVariables = new GestionVariablesFinancieras();

        // Solicitar al usuario los detalles de la primera variable
        Console.WriteLine("Ingrese los detalles de la primera variable:");
        Console.Write("ID: ");
        int id1 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre1 = Console.ReadLine();
        Console.Write("Valor: ");
        decimal valor1 = decimal.Parse(Console.ReadLine());

        // Agregar variable con los detalles proporcionados
        gestionVariables.AgregarVariable(new VariableFinanciera { Id = id1, Nombre = nombre1, Valor = valor1 });

        // Solicitar al usuario los detalles de la segunda variable
        Console.WriteLine("Ingrese los detalles de la segunda variable:");
        Console.Write("ID: ");
        int id2 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre2 = Console.ReadLine();
        Console.Write("Valor: ");
        decimal valor2 = decimal.Parse(Console.ReadLine());

        // Agregar variable con los detalles proporcionados
        gestionVariables.AgregarVariable(new VariableFinanciera { Id = id2, Nombre = nombre2, Valor = valor2 });

        // Mostrar variables
        gestionVariables.MostrarVariables();

        // Actualizar variable
        gestionVariables.ActualizarVariable(id2, new VariableFinanciera { Nombre = "Gastos", Valor = 32000 });

        // Mostrar variables después de la actualización
        gestionVariables.MostrarVariables();

        // Eliminar variable
        gestionVariables.EliminarVariable(id1);

        // Mostrar variables después de la eliminación
        gestionVariables.MostrarVariables();
    }

    static void metedohilo2()
    {
        GestionVariablesFinancieras gestionVariables = new GestionVariablesFinancieras();

        // Solicitar al usuario los detalles de la tercera variable
        Console.WriteLine("Ingrese los detalles de la tercera variable:");
        Console.Write("ID: ");
        int id3 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre3 = Console.ReadLine();
        Console.Write("Valor: ");
        decimal valor3 = decimal.Parse(Console.ReadLine());

        // Agregar variable con los detalles proporcionados
        gestionVariables.AgregarVariable(new VariableFinanciera { Id = id3, Nombre = nombre3, Valor = valor3 });

        // Mostrar variables
        gestionVariables.MostrarVariables();
    }

    static void metedohilo3()
    {
        GestionVariablesFinancieras gestionVariables = new GestionVariablesFinancieras();

        // Realizar algún cálculo adicional (simulación)
        Console.WriteLine("Cálculo adicional...");
    }
}
