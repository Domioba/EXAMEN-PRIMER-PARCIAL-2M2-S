﻿using System;
using System.Collections.Generic;
using System.Threading;

public class Empleado
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Puesto { get; set; }
    public decimal Salario { get; set; }
}

public class GestionEmpleados
{
    private List<Empleado> empleados;

    public GestionEmpleados()
    {
        empleados = new List<Empleado>();
    }

    public void AgregarEmpleado(Empleado empleado)
    {
        empleados.Add(empleado);
    }

    public void MostrarEmpleados()
    {
        Console.WriteLine("Listado de Empleados:");
        foreach (var empleado in empleados)
        {
            Console.WriteLine($"ID: {empleado.Id}, Nombre: {empleado.Nombre}, Puesto: {empleado.Puesto}, Salario: {empleado.Salario}");
        }
    }

    public void ActualizarEmpleado(int id, Empleado empleadoActualizado)
    {
        var empleadoExistente = empleados.Find(e => e.Id == id);
        if (empleadoExistente != null)
        {
            empleadoExistente.Nombre = empleadoActualizado.Nombre;
            empleadoExistente.Puesto = empleadoActualizado.Puesto;
            empleadoExistente.Salario = empleadoActualizado.Salario;
            Console.WriteLine("Empleado actualizado correctamente.");
        }
        else
        {
            Console.WriteLine("Empleado no encontrado.");
        }
    }

    public void EliminarEmpleado(int id)
    {
        var empleadoExistente = empleados.Find(e => e.Id == id);
        if (empleadoExistente != null)
        {
            empleados.Remove(empleadoExistente);
            Console.WriteLine("Empleado eliminado correctamente.");
        }
        else
        {
            Console.WriteLine("Empleado no encontrado.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Thread t = new Thread(metedohilo1);
        t.Start();
        t.Join();
        Thread t2 = new Thread(metedohilo2);
        t2.Start();
        t2.Join();
        Thread t3 = new Thread(metedohilo3);
        t3.Start();
        t3.Join();
    }

    static void metedohilo1()
    {
        GestionEmpleados gestionEmpleados = new GestionEmpleados();

        // Solicitar al usuario los detalles del primer empleado
        Console.WriteLine("Ingrese los detalles del primer empleado:");
        Console.Write("ID: ");
        int id1 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre1 = Console.ReadLine();
        Console.Write("Puesto: ");
        string puesto1 = Console.ReadLine();
        Console.Write("Salario: ");
        decimal salario1 = decimal.Parse(Console.ReadLine());

        // Agregar empleado con los detalles proporcionados
        gestionEmpleados.AgregarEmpleado(new Empleado { Id = id1, Nombre = nombre1, Puesto = puesto1, Salario = salario1 });

        // Solicitar al usuario los detalles del segundo empleado
        Console.WriteLine("Ingrese los detalles del segundo empleado:");
        Console.Write("ID: ");
        int id2 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre2 = Console.ReadLine();
        Console.Write("Puesto: ");
        string puesto2 = Console.ReadLine();
        Console.Write("Salario: ");
        decimal salario2 = decimal.Parse(Console.ReadLine());

        // Agregar empleado con los detalles proporcionados
        gestionEmpleados.AgregarEmpleado(new Empleado { Id = id2, Nombre = nombre2, Puesto = puesto2, Salario = salario2 });

        // Mostrar empleados
        gestionEmpleados.MostrarEmpleados();

        // Actualizar empleado
        gestionEmpleados.ActualizarEmpleado(id2, new Empleado { Nombre = nombre2, Puesto = puesto2, Salario = salario2 });

        // Mostrar empleados después de la actualización
        gestionEmpleados.MostrarEmpleados();

        // Eliminar empleado
        gestionEmpleados.EliminarEmpleado(id1);

        // Mostrar empleados después de la eliminación
        gestionEmpleados.MostrarEmpleados();
    }

    static void metedohilo2()
    {
        GestionEmpleados gestionEmpleados = new GestionEmpleados();

        // Agregar más empleados (simulación)
        gestionEmpleados.AgregarEmpleado(new Empleado { Id = 3, Nombre = "Carlos", Puesto = "Analista", Salario = 4000 });
        gestionEmpleados.AgregarEmpleado(new Empleado { Id = 4, Nombre = "Laura", Puesto = "Diseñador", Salario = 3500 });

        // Mostrar empleados
        gestionEmpleados.MostrarEmpleados();
    }

    static void metedohilo3()
    {
        GestionEmpleados gestionEmpleados = new GestionEmpleados();

        // Realizar algún cálculo o análisis basado en los datos de los empleados (simulación)
        decimal totalSalarios = 0;
        foreach (var empleado in gestionEmpleados)
        {
            totalSalarios += empleado.Salario;
        }

        Console.WriteLine($"El total de salarios de los empleados es: {totalSalarios}");
    }
}
    