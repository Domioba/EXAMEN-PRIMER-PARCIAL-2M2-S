﻿using System;
using System.IO;
using System.Threading;

class Program
{
    static string filePath = "punto_equilibrio.txt";

    static void Main(string[] args)
    {
        Console.WriteLine("Cálculo de Punto de Equilibrio");

        while (true)
        {
            MostrarMenu();
        }
    }

    static void MostrarMenu()
    {
        Console.WriteLine("\nMenú:");
        Console.WriteLine("1. Calcular punto de equilibrio");
        Console.WriteLine("2. Ver datos guardados");
        Console.WriteLine("3. Actualizar datos");
        Console.WriteLine("4. Eliminar datos");
        Console.WriteLine("5. Salir");

        Console.Write("\nSeleccione una opción: ");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Thread t1 = new Thread(CalcularPuntoEquilibrio);
                t1.Start();
                t1.Join();
                break;
            case "2":
                VerDatosGuardados();
                break;
            case "3":
                Thread t2 = new Thread(ActualizarDatos);
                t2.Start();
                t2.Join();
                break;
            case "4":
                Thread t3 = new Thread(EliminarDatos);
                t3.Start();
                t3.Join();
                break;
            case "5":
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                break;
        }
    }

    static void CalcularPuntoEquilibrio()
    {
        Console.Write("\nIngrese el costo fijo total: ");
        double costoFijoTotal = Convert.ToDouble(Console.ReadLine());

        Console.Write("Ingrese el precio de venta por unidad: ");
        double precioVentaUnidad = Convert.ToDouble(Console.ReadLine());

        Console.Write("Ingrese el costo variable por unidad: ");
        double costoVariableUnidad = Convert.ToDouble(Console.ReadLine());

        double puntoEquilibrio = costoFijoTotal / (precioVentaUnidad - costoVariableUnidad);
        Console.WriteLine("El punto de equilibrio es: " + puntoEquilibrio);

        GuardarDatos(costoFijoTotal, precioVentaUnidad, costoVariableUnidad, puntoEquilibrio);
    }

    static void GuardarDatos(double costoFijoTotal, double precioVentaUnidad, double costoVariableUnidad, double puntoEquilibrio)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.WriteLine("Costo Fijo Total: " + costoFijoTotal);
            writer.WriteLine("Precio de Venta por Unidad: " + precioVentaUnidad);
            writer.WriteLine("Costo Variable por Unidad: " + costoVariableUnidad);
            writer.WriteLine("Punto de Equilibrio: " + puntoEquilibrio);
        }

        Console.WriteLine("Datos guardados en " + filePath);
    }

    static void VerDatosGuardados()
    {
        if (File.Exists(filePath))
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }
        }
        else
        {
            Console.WriteLine("No hay datos guardados.");
        }
    }

    static void ActualizarDatos()
    {
        if (File.Exists(filePath))
        {
            Console.WriteLine("Los datos existentes se actualizarán. Ingrese los nuevos valores:");

            CalcularPuntoEquilibrio();
        }
        else
        {
            Console.WriteLine("No hay datos guardados para actualizar.");
        }
    }

    static void EliminarDatos()
    {
        if (File.Exists(filePath))
        {
            File.Delete(filePath);
            Console.WriteLine("Datos eliminados correctamente.");
        }
        else
        {
            Console.WriteLine("No hay datos guardados para eliminar.");
        }
    }
}

