﻿using System;
using System.IO;

namespace ContabilidadGerencial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Contabilidad Gerencial");
            Console.WriteLine("--------------------");

            while (true)
            {
                Console.WriteLine("1. Crear Transacción");
                Console.WriteLine("2. Leer Transacciones");
                Console.WriteLine("3. Actualizar Transacción");
                Console.WriteLine("4. Borrar Transacción");
                Console.WriteLine("5. Salir");

                Console.Write("Elija una opción: ");
                int opcion;
                if (!int.TryParse(Console.ReadLine(), out opcion))
                {
                    Console.WriteLine("Opción inválida. Intente de nuevo.");
                    continue;
                }

                switch (opcion)
                {
                    case 1:
                        CrearTransaccion();
                        break;
                    case 2:
                        LeerTransacciones();
                        break;
                    case 3:
                        ActualizarTransaccion();
                        break;
                    case 4:
                        BorrarTransaccion();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opción inválida");
                        break;
                }
            }
        }

        static void CrearTransaccion()
        {
            try
            {
                Console.Write("Ingrese fecha (aaaa-mm-dd): ");
                string fecha = Console.ReadLine();

                Console.Write("Ingrese tipo (Ingreso/Egreso): ");
                string tipo = Console.ReadLine();

                Console.Write("Ingrese monto: ");
                double monto;
                if (!double.TryParse(Console.ReadLine(), out monto))
                {
                    Console.WriteLine("Monto no válido. Intente de nuevo.");
                    return;
                }

                string archivo = Path.Combine("Transacciones", $"Transaccion_{fecha}.txt");
                Directory.CreateDirectory("Transacciones");
                File.WriteAllText(archivo, $"{fecha},{tipo},{monto}");

                Console.WriteLine("Transacción creada exitosamente!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al crear la transacción: {ex.Message}");
            }
        }

        static void LeerTransacciones()
        {
            try
            {
                string[] archivos = Directory.GetFiles("Transacciones");

                foreach (string archivo in archivos)
                {
                    using (StreamReader lector = File.OpenText(archivo))
                    {
                        string linea = lector.ReadLine();
                        string[] partes = linea.Split(',');
                        Console.WriteLine($"Fecha: {partes[0]}, Tipo: {partes[1]}, Monto: {partes[2]}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al leer las transacciones: {ex.Message}");
            }
        }

        static void ActualizarTransaccion()
        {
            try
            {
                Console.Write("Ingrese fecha (aaaa-mm-dd): ");
                string fecha = Console.ReadLine();

                Console.Write("Ingrese nuevo tipo (Ingreso/Egreso): ");
                string tipo = Console.ReadLine();

                Console.Write("Ingrese nuevo monto: ");
                double monto;
                if (!double.TryParse(Console.ReadLine(), out monto))
                {
                    Console.WriteLine("Monto no válido. Intente de nuevo.");
                    return;
                }

                string archivo = Path.Combine("Transacciones", $"Transaccion_{fecha}.txt");
                if (File.Exists(archivo))
                {
                    File.WriteAllText(archivo, $"{fecha},{tipo},{monto}");
                    Console.WriteLine("Transacción actualizada exitosamente!");
                }
                else
                {
                    Console.WriteLine("Transacción no encontrada");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al actualizar la transacción: {ex.Message}");
            }
        }

        static void BorrarTransaccion()
        {
            try
            {
                Console.Write("Ingrese fecha (aaaa-mm-dd): ");
                string fecha = Console.ReadLine();

                string archivo = Path.Combine("Transacciones", $"Transaccion_{fecha}.txt");
                if (File.Exists(archivo))
                {
                    File.Delete(archivo);
                    Console.WriteLine("Transacción eliminada exitosamente!");
                }
                else
                {
                    Console.WriteLine("Transacción no encontrada");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al borrar la transacción: {ex.Message}");
            }
        }
    }
}
