﻿using System;
using System.IO;
using System.Threading;

public class Producto
{
    public string Nombre { get; set; }
    public double PrecioVenta { get; set; }
    public double CostoVariableUnitario { get; set; }
    public int CantidadProducida { get; set; }

    public double CalcularCostoProduccion()
    {
        return CostoVariableUnitario * CantidadProducida;
    }

    public double CalcularUtilidad()
    {
        return (PrecioVenta - CostoVariableUnitario) * CantidadProducida;
    }

    // Método para guardar los datos del producto en un archivo
    public void GuardarDatos(string archivo)
    {
        using (FileStream fs = new FileStream(archivo, FileMode.Create))
        {
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.WriteLine($"Nombre del Producto: {Nombre}");
                writer.WriteLine($"Precio de Venta: {PrecioVenta}");
                writer.WriteLine($"Costo Variable Unitario: {CostoVariableUnitario}");
                writer.WriteLine($"Cantidad Producida: {CantidadProducida}");
                writer.WriteLine($"Costo de Producción: {CalcularCostoProduccion()}");
                writer.WriteLine($"Utilidad: {CalcularUtilidad()}");
            }
        }
    }

    // Método para cargar los datos del producto desde un archivo
    public static Producto CargarDatos(string archivo)
    {
        Producto producto = new Producto();
        try
        {
            using (FileStream fs = new FileStream(archivo, FileMode.Open))
            {
                using (StreamReader reader = new StreamReader(fs))
                {
                    producto.Nombre = reader.ReadLine()?.Split(':')[1]?.Trim();
                    producto.PrecioVenta = double.Parse(reader.ReadLine()?.Split(':')[1]?.Trim());
                    producto.CostoVariableUnitario = double.Parse(reader.ReadLine()?.Split(':')[1]?.Trim());
                    producto.CantidadProducida = int.Parse(reader.ReadLine()?.Split(':')[1]?.Trim());
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al cargar los datos del producto: " + ex.Message);
        }
        return producto;
    }

    // Método para actualizar los datos del producto
    public void ActualizarDatos(double nuevoPrecioVenta, double nuevoCostoVariableUnitario, int nuevaCantidadProducida)
    {
        PrecioVenta = nuevoPrecioVenta;
        CostoVariableUnitario = nuevoCostoVariableUnitario;
        CantidadProducida = nuevaCantidadProducida;
    }

    // Método para eliminar los datos del producto
    public void EliminarDatos(string archivo)
    {
        File.Delete(archivo);
        Console.WriteLine("Los datos del producto han sido eliminados.");
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Crear hilos para ejecutar cada operación CRUD
        Thread crearThread = new Thread(CrearProducto);
        Thread leerThread = new Thread(LeerProducto);
        Thread actualizarThread = new Thread(ActualizarProducto);
        Thread eliminarThread = new Thread(EliminarProducto);

        // Iniciar y esperar a que finalicen los hilos secuencialmente
        crearThread.Start();
        crearThread.Join();
        leerThread.Start();
        leerThread.Join();
        actualizarThread.Start();
        actualizarThread.Join();
        eliminarThread.Start();
        eliminarThread.Join();
    }

    static void CrearProducto()
    {
        Console.WriteLine("Hilo 1: Crear un nuevo producto");

        Console.WriteLine("\nIngrese los datos del nuevo producto:");
        Console.Write("Nombre del Producto: ");
        string nombre = Console.ReadLine();
        Console.Write("Precio de Venta: ");
        double precioVenta = double.Parse(Console.ReadLine());
        Console.Write("Costo Variable Unitario: ");
        double costoVariableUnitario = double.Parse(Console.ReadLine());
        Console.Write("Cantidad Producida: ");
        int cantidadProducida = int.Parse(Console.ReadLine());

        Producto nuevoProducto = new Producto
        {
            Nombre = nombre,
            PrecioVenta = precioVenta,
            CostoVariableUnitario = costoVariableUnitario,
            CantidadProducida = cantidadProducida
        };

        nuevoProducto.GuardarDatos($"{nombre.ToLower().Replace(" ", "_")}.txt");
        Console.WriteLine("¡Producto creado con éxito!");
    }

    static void LeerProducto()
    {
        Console.WriteLine("\nHilo 2: Leer datos de un producto");
        Console.Write("Ingrese el nombre del producto: ");
        string nombre = Console.ReadLine().ToLower().Replace(" ", "_") + ".txt";

        if (File.Exists(nombre))
        {
            Producto producto = Producto.CargarDatos(nombre);
            Console.WriteLine("\nDatos del producto:");
            Console.WriteLine($"Nombre del Producto: {producto.Nombre}");
            Console.WriteLine($"Precio de Venta: {producto.PrecioVenta}");
            Console.WriteLine($"Costo Variable Unitario: {producto.CostoVariableUnitario}");
            Console.WriteLine($"Cantidad Producida: {producto.CantidadProducida}");
            Console.WriteLine($"Costo de Producción: {producto.CalcularCostoProduccion()}");
            Console.WriteLine($"Utilidad: {producto.CalcularUtilidad()}");
        }
        else
        {
            Console.WriteLine("El producto no existe.");
        }
    }

    static void ActualizarProducto()
    {
        Console.WriteLine("\nHilo 3: Actualizar datos de un producto");
        Console.Write("Ingrese el nombre del producto a actualizar: ");
        string nombre = Console.ReadLine().ToLower().Replace(" ", "_") + ".txt";

        if (File.Exists(nombre))
        {
            Console.Write("¿Desea actualizar los datos del producto? (S/N): ");
            string respuesta = Console.ReadLine().ToUpper();

            if (respuesta == "S")
            {
                Producto producto = Producto.CargarDatos(nombre);

                Console.WriteLine("\nDatos actuales del producto:");
                Console.WriteLine($"Nombre del Producto: {producto.Nombre}");
                Console.WriteLine($"Precio de Venta: {producto.PrecioVenta}");
                Console.WriteLine($"Costo Variable Unitario: {producto.CostoVariableUnitario}");
                Console.WriteLine($"Cantidad Producida: {producto.CantidadProducida}");

                Console.WriteLine("\nIngrese los nuevos datos del producto:");
                Console.Write("Nuevo Precio de Venta: ");
                double nuevoPrecioVenta = double.Parse(Console.ReadLine());
                Console.Write("Nuevo Costo Variable Unitario: ");
                double nuevoCostoVariableUnitario = double.Parse(Console.ReadLine());
                Console.Write("Nueva Cantidad Producida: ");
                int nuevaCantidadProducida = int.Parse(Console.ReadLine());

                producto.ActualizarDatos(nuevoPrecioVenta, nuevoCostoVariableUnitario, nuevaCantidadProducida);
                producto.GuardarDatos(nombre);

                Console.WriteLine("¡Producto actualizado con éxito!");
            }
            else
            {
                Console.WriteLine("Operación cancelada.");
            }
        }
        else
        {
            Console.WriteLine("El producto no existe.");
        }
    }

    static void EliminarProducto()
    {
        Console.WriteLine("\nHilo 4: Eliminar datos de un producto");
        Console.Write("Ingrese el nombre del producto a eliminar: ");
        string nombre = Console.ReadLine().ToLower().Replace(" ", "_") + ".txt";

        if (File.Exists(nombre))
        {
            Console.Write("¿Desea eliminar los datos del producto? (S/N): ");
            string respuesta = Console.ReadLine().ToUpper();

            if (respuesta == "S")
            {
                Console.Write("¿Está seguro de que desea eliminar los datos del producto? (S/N): ");
                respuesta = Console.ReadLine().ToUpper();

                if (respuesta == "S")
                {
                    Producto producto = Producto.CargarDatos(nombre);
                    producto.EliminarDatos(nombre);
                }
                else
                {
                    Console.WriteLine("Operación cancelada.");
                }
            }
            else
            {
                Console.WriteLine("Operación cancelada.");
            }
        }
        else
        {
            Console.WriteLine("El producto no existe.");
        }
    }
}
